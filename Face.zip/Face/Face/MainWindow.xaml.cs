﻿using Microsoft.Azure.CognitiveServices.Vision.Face;
using Microsoft.Azure.CognitiveServices.Vision.Face.Models;

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.ProjectOxford.Face;
using Microsoft.ProjectOxford.Face.Contract;

namespace Face
{
    

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            FaceServiceClient faceServiceClient = new FaceServiceClient("<Subscription Key>", "https://centralindia.api.cognitive.microsoft.com/face/v1.0");
            Bu(faceServiceClient);
        }

        private async void Bu(FaceServiceClient faceServiceClient)
        {
            // Create an empty PersonGroup
            string personGroupId = "person";
            await faceServiceClient.CreatePersonGroupAsync(personGroupId, "My Friends");

            CreatePersonResult friend1 = await faceServiceClient.CreatePersonAsync(personGroupId, "Anna");
            CreatePersonResult friend2 = await faceServiceClient.CreatePersonAsync(personGroupId, "Bill");
            CreatePersonResult friend3 = await faceServiceClient.CreatePersonAsync(personGroupId, "Clare");
            CreatePersonResult friend4 = await faceServiceClient.CreatePersonAsync(personGroupId, "David");


            // Directory contains image files of Anna
            const string friend1ImageDir = @"C:\Users\This PC\source\repos\Face\Face\Sample\Anna";

            foreach (string imagePath in Directory.GetFiles(friend1ImageDir, "*.jpg"))
            {
                using (Stream s = File.OpenRead(imagePath))
                {
                    // Detect faces in the image and add to Anna
                    await faceServiceClient.AddPersonFaceAsync(personGroupId, friend1.PersonId, s);
                }
            }

            // Directory contains image files of Bill
            const string friend2ImageDir = @"C:\Users\This PC\source\repos\Face\Face\Sample\Bill";

            foreach (string imagePath in Directory.GetFiles(friend2ImageDir, "*.jpg"))
            {
                using (Stream s = File.OpenRead(imagePath))
                {
                    // Detect faces in the image and add to Bill
                    await faceServiceClient.AddPersonFaceAsync(personGroupId, friend2.PersonId, s);
                }
            }

            // Directory contains image files of Clare
            const string friend3ImageDir = @"C:\Users\This PC\source\repos\Face\Face\Sample\Clare";

            foreach (string imagePath in Directory.GetFiles(friend3ImageDir, "*.jpg"))
            {
                using (Stream s = File.OpenRead(imagePath))
                {
                    // Detect faces in the image and add to Clare
                    await faceServiceClient.AddPersonFaceAsync(personGroupId, friend3.PersonId, s);
                }
            }

            // Directory contains image files of David
            const string friend4ImageDir = @"C:\Users\This PC\source\repos\Face\Face\Sample\David";

            foreach (string imagePath in Directory.GetFiles(friend4ImageDir, "*.jpg"))
            {
                using (Stream s = File.OpenRead(imagePath))
                {
                    // Detect faces in the image and add to David
                    await faceServiceClient.AddPersonFaceAsync(personGroupId, friend4.PersonId, s);
                }
            }

            await faceServiceClient.TrainPersonGroupAsync(personGroupId);
            Microsoft.ProjectOxford.Face.Contract.TrainingStatus trainingStatus = null;
            while (true)
            {
                trainingStatus = await faceServiceClient.GetPersonGroupTrainingStatusAsync(personGroupId);

                if (trainingStatus.Status != Status.Running)
                {
                    break;
                }

                await Task.Delay(1000);
            }
        }
    }
}